from django.apps import AppConfig


class PrioridadesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prioridades'
